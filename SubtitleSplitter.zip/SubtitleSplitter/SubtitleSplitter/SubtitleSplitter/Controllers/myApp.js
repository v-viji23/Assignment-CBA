﻿var myApp = angular.module('myApp', ['ngMessages']);


myApp.controller('myCtrl', ['$scope', '$http', function ($scope, $http) {
    $scope.ShowSubtitle = function () {
        if ($scope.mytext != undefined) {
            $http.get('/api/Subtitle/Parse?input=' + $scope.mytext)
                .then(function (response) {
                    $scope.Subtitle = response.data;
                });
        }
    };
}]);