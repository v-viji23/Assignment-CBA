﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Web.Http;

namespace SubtitleSplitter.Controllers
{
    public class SubtitleController : ApiController
    {
        [HttpGet]
        [Route("api/Subtitle/Parse")]
        public string[] Parse([FromUri]string input)
        {
            List<string> ls = new List<string>();
            int maxChunkSize = 25;
            if (!string.IsNullOrEmpty(input))
            {
                input = Regex.Replace(input, @"\s+", " ");
                int strLength = input.Length;
                for (int i = 0; i < strLength;)
                {
                    bool HasCommaOrDot = false;
                    if (i + maxChunkSize > strLength)
                    {
                        maxChunkSize = strLength - i;
                    }
                    string chunk = input.Substring(i, maxChunkSize);

                    int index = 0;
                    if (chunk.Contains('.') && chunk.Contains(','))
                    {
                        index = (chunk.IndexOf(',') < chunk.IndexOf('.')) ? chunk.IndexOf(',') : chunk.IndexOf('.');
                    }
                    else if (chunk.Contains(','))
                    {
                        index = chunk.IndexOf(',');
                    }
                    else if (chunk.Contains('.'))
                    {
                        index = chunk.IndexOf('.');
                    }
                    else
                    {
                        ls.Add(chunk);
                        i += maxChunkSize;
                        continue;
                    }
                    if (index <= 4)
                    {
                        for (int j = index + 1; j < index + 5; j++)
                        {
                            HasCommaOrDot = (chunk[j] == '.' || chunk[j] == ',');
                            if (HasCommaOrDot) break;
                        }
                        if (!HasCommaOrDot)
                        {
                            chunk = chunk.Substring(0, index + 1);
                            ls.Add(chunk);
                            i += index + 1;
                            continue;
                        }
                    }
                    ls.Add(chunk);
                    i += maxChunkSize;
                }                          
            }
            return ls.ToArray();
        }
        // GET: api/Subtitle
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Subtitle/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Subtitle
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Subtitle/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Subtitle/5
        public void Delete(int id)
        {
        }
    }
}
